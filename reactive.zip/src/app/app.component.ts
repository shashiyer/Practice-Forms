import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormArray } from "@angular/forms";
import { forbiddenNameValidator } from "src/app/shared/user-name.validator";
import { passwordValidator } from "src/app/shared/password.validator";
import { RegistrationService } from "./registration.service";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

registrationForm : FormGroup;

get userName()
{
  return this.registrationForm.get('userName');
}

get email()
{
  return this.registrationForm.get('email');
}

get alternativeEmails()
{
  return this.registrationForm.get('alternativeEmails') as FormArray;
}

addAlternativeEmails()
{
  return this.alternativeEmails.push(this.fb.control(''));
}

ngOnInit()
{
  this.registrationForm = this.fb.group({
  userName : ['', [Validators.required, Validators.minLength(3), forbiddenNameValidator(/admin/)]],
  email : [''],
  subscribe : [false],
  password : [''],
  confirmPassword : [''],
     address : this.fb.group({
        city: [''],
        state: [''],
        pincode: ['']
      }),
      alternativeEmails : this.fb.array([])
}, {validator : passwordValidator});

this.registrationForm.get('subscribe').valueChanges
.subscribe(checkedValue => {
const email = this.registrationForm.get('email');

if(checkedValue)
{
  email.setValidators(Validators.required);
}

else{
  email.clearValidators();
}

email.updateValueAndValidity();
});
  
}

  constructor(private fb : FormBuilder, private registrationService : RegistrationService){}
  
  // registrationForm = new FormGroup({
  //   userName : new FormControl('Shash'),
  //       password : new FormControl(''),
  //       confirmPassword : new FormControl(''),
  //       address : new FormGroup({
  //       city : new FormControl(''),
  //       state : new FormControl(''),
  //       pincode : new FormControl(''),
  //       })
  // });

  
  loadApiData()
  {
    // this.registrationForm.setValue( --> sets control to all the values
      this.registrationForm.patchValue(
        // patchvalue is used to set the control to only few values
    {
      userName : 'Shash',
      password : 'test',
      confirmPassword : 'test',
      // address : {
      //   city: 'Banaglore',
      //   state: 'Karnataka',
      //   pincode: '123456'
      // }

    });
  }

  onSubmit()
  {
    console.log(this.registrationForm.value);
    this.registrationService.register(this.registrationForm.value).subscribe
    (
      response => console.log('Success', response),
      error => console.log('Error', error)
    );
  }
}
