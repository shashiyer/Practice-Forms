import { Component } from '@angular/core';
import { User } from "src/user";
import { EnrollmentService } from './enrollment.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent
{
  title = 'Practice Forms';

  topics = ['Angular','React','View'];

  topicHasError = true;
  
  userModel = new User('Shashank','shash@gmail.com',1234567890,'default','morning','No 12','Bangalore','Karnataka',12345,true);

  constructor(private enrollmentService : EnrollmentService){}

  validateTopic(value)
  {

    if(value === 'default') 
    {
      this.topicHasError = true;
    }

    else
    {
      this.topicHasError = false;
    }
  }

  onSubmit()
  {
    this.enrollmentService.enroll(this.userModel)
    .subscribe(data => console.log('Success', data), error => console.error('Error', error));
  }
}
